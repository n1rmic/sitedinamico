<?php





$senha = 789456;
echo $senha;
$senhacriptografada = md5($senha);
echo "senha criptografada: $senhacriptografada";


