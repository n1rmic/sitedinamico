<?php
    session_start();
    include("../include/cabecalho.php");
?>


    <div class="container">

      <form class="form-signin" method="POST" action="valida.php">
        <h2 class="form-signin-heading">Área Restrita</h2>
        <label for="inputEmail" class="sr-only">Usuário</label>
        <input type="email" name="txt_usuario" id="inputEmail" class="form-control" placeholder="Usuário" required autofocus>
        <label for="inputPassword" class="sr-only">Senha</label>
        <input type="password" name="txt_senha" id="inputPassword" class="form-control" placeholder="Senha" required>
        <button class="btn btn-lg btn-danger btn-block" type="submit">Acessar</button>
        <p class="text-center text-danger">
            <?php if(isset($_SESSION['loginErro'])){
                echo $_SESSION['loginErro'];
                unset ($_SESSION['loginErro']);
            }?>
        </p>
        <p class="text-center text-success">
            <?php if(isset($_SESSION['loginDeslogado'])){
                echo $_SESSION['loginDeslogado'];
                unset ($_SESSION['loginDeslogado']);
            }?>
        </p>
      </form>
    </div> <!-- /container -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
