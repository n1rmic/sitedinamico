<?php
    session_start();
    include_once("seguranca.php");
    include_once("conexao/conexao.php");
    seguranca_adm();
?>
<br>






<a href="sair.php">Sair</a>