<?php
include('../include/cabecalho.php');
include('../conexao/conexao.php');
include('../include/menu.php');
?>
<br>
<br>
<div class="row">
  <div class="col">
    <!-- Name input -->
    <div class="form-outline">
      <input type="text" id="form8Example1" class="form-control" />
      <label class="form-label" for="form8Example1">ID</label>
    </div>
  </div>
  <div class="col">
    <!-- Email input -->
    <div class="form-outline">
      <input type="email" id="form8Example2" class="form-control" />
      <label class="form-label" for="form8Example2">Modelo</label>
    </div>
  </div>
</div>

<hr />

<div class="row">
  <div class="col">
    <!-- Name input -->
    <div class="form-outline">
      <input type="text" id="form8Example3" class="form-control" />
      <label class="form-label" for="form8Example3">Fabricante</label>
    </div>
  </div>
  <div class="col">
    <!-- Name input -->
    <div class="form-outline">
      <input type="text" id="form8Example4" class="form-control" />
      <label class="form-label" for="form8Example4">Quantidade</label>
    </div>
  </div>
  <div class="col">
   

<div class="col-auto">
    <button type="submit" class="btn btn-primary">Cadastrar Produto</button>
  </div>



  </div>
</div>