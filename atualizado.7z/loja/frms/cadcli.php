<?php
include('../include/cabecalho.php');
include('../conexao/conexao.php');
include('../include/menu.php');
?>

<form >
  <div class="row">
    <div class="col-6 col-md-4">
      Nome Completo:
      <input type="text" id="nome_passageiro2" name="nome">
      <br/><br/>
  </div>
 <div class="col-6 col-md-4">
  CEP:
  <input type="text" id="cep" name="cep">
  <button type="button" id="buscar_cep">
    buscar
    <i class="fa fa-search" action="" ></i>
  </button>
  <br/><br/>
 </div>
 <div class="col-6 col-md-4">
    Celular:<input type="text" id="nr_celular" name="celular"><br/><br/>
 </div>

  <div class="col-6 col-md-4">
    CPF:<input type="text" id="cpf" name="cpf" ><br/><br/>
  </div>

  <div class="col-6 col-md-4">
    UF:<input type="text" id="uf" name="uf" ><br/><br/>
 </div>

 <div class="col-6 col-md-4">
    Cidade:<input type="text" id="cidade" name="uf"><br/><br/>
 </div>
    </div>

    <div class="row">

        <div class="col-6 col-md-4">
    Rua:<input type="text" id="rua" name="endereco"><br/><br/>
 </div>

           <div class="col-6 col-md-4">
    Estado:<input type="text" id="estado" name="endereco"><br/><br/>
 </div>

         <div class="col-6 col-md-4">
    Bairro:<input type="text" id="bairro" name="endereco"><br/><br/>
 </div>
        <div class="col-6 col-md-4">
    Telefone:<input type="text" id="modelo" name="telefone"><br/><br/>
        </div>

        <div class="col-6 col-md-4">
    Login:<input type="text" id="login" name="login"><br/><br/>
        </div>

        <div class="col-6 col-md-4">
            Senha:<input type="password" id="senha" name="senha"><br/><br/>
        </div>

        <div class="col-6 col-md-4">
            Confirmar Senha:<input type="password" id="senha" name="confirma_senha"><br/><br/>
        </div>
        <div class="col-6 col-md-4">
     Data de Nascimento:<input type="text" id="nascimento_dt" name="nascimento"><br/><br/>
 </div>

            <div class="col-6 col-md-4">
    Estado Civil:  <label for="s1">Solteiro(a)</label>
        <input type="radio" id="ativo" name="status"  value="ativo"/>

        <label for="s2">Casado(a)</label>
        <input type="radio" id="inativo" name="status" value="inativo"/>
  <br/><br/>
            </div>





             <div class="col-6 col-md-4">
    Sexo:  <label for="s4">Masculino</label>
        <input type="radio" id="masc" name="sexo" value="masculino"/>

        <label for="s6">Feminino</label>
        <input type="radio" id="fem" name="sexo" value="feminino"/><br/>
    <br/>

        </div>
    </div>

        <button type="submit" onclick="validar()" >Cadastrar</button> 


    </form>