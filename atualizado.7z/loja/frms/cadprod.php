<?php
include('../include/cabecalho.php');
include('../conexao/conexao.php');
include('../include/menu.php');
?>

<form >
  <div class="row">
    <div class="col-6 col-md-4">
     ID:
      <input type="number" id="id" name="id">
      <br/><br/>
  </div>
 <div class="col-6 col-md-4">
 Modelo:
  <input type="text" id="cep" name="cep">
  
  <br/><br/>
 </div>
 <div class="col-6 col-md-4">
    Fabricante
    <input type="text" id="nr_celular" name="fabricante"><br/><br/>
 </div>

  <div class="col-6 col-md-4">
   Quantidade:
    <input type="text" id="cpf" name="cpf" ><br/><br/>
  </div>

  

        <button type="submit" onclick="validar()" >Cadastrar</button> 


    </form>